package com.github.wezde.wezdetelegrambot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WezdeTelegrambotApplication {

	public static void main(String[] args) {
		SpringApplication.run(WezdeTelegrambotApplication.class, args);
	}

}
